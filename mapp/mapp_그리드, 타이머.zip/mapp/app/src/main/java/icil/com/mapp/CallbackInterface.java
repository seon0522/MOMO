package icil.com.mapp;

import java.io.File;

public interface CallbackInterface {
    void onSave(File filePath);
}

